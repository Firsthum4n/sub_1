self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "74a670f38a05a57adc8099f070b015ae",
    "url": "./index.html"
  },
  {
    "revision": "4fc728e3adee18b498b2",
    "url": "./static/css/2.20245710.chunk.css"
  },
  {
    "revision": "4c5c928acace80d82a61",
    "url": "./static/css/main.d80fdd0a.chunk.css"
  },
  {
    "revision": "4fc728e3adee18b498b2",
    "url": "./static/js/2.3f02b3fb.chunk.js"
  },
  {
    "revision": "8067edf00042dc4464e4b3354e12578e",
    "url": "./static/js/2.3f02b3fb.chunk.js.LICENSE.txt"
  },
  {
    "revision": "4c5c928acace80d82a61",
    "url": "./static/js/main.c7e98b13.chunk.js"
  },
  {
    "revision": "350e0bde90825074ef5c",
    "url": "./static/js/runtime-main.4a004120.js"
  },
  {
    "revision": "8e299767abae990bc8ff82bd42d93aff",
    "url": "./static/media/arrow.8e299767.svg"
  },
  {
    "revision": "48d9b56f183ebfebc92e91f2147aad19",
    "url": "./static/media/audio.48d9b56f.svg"
  },
  {
    "revision": "ceb3f7253dd768937e999b51b103d07a",
    "url": "./static/media/delete_icon.ceb3f725.svg"
  },
  {
    "revision": "1ab0e91cb2cc2edb0cb2988ccce04b51",
    "url": "./static/media/download.1ab0e91c.svg"
  },
  {
    "revision": "07787ab5581867417e347d9bd4edf6ca",
    "url": "./static/media/mixedContent.07787ab5.svg"
  },
  {
    "revision": "c5817d7169aa221b7bd441866d67de48",
    "url": "./static/media/modal_close.c5817d71.svg"
  },
  {
    "revision": "ca174ea95250fd214933a2923986d7d7",
    "url": "./static/media/photo1.ca174ea9.jpg"
  },
  {
    "revision": "f1818abb48811996b290dec4ce941636",
    "url": "./static/media/plus.f1818abb.svg"
  },
  {
    "revision": "7c9f5af4ec73ac7bb2ebda5f6eb63f6b",
    "url": "./static/media/settings.7c9f5af4.svg"
  },
  {
    "revision": "751795638d8842a950a7095faf2aedaa",
    "url": "./static/media/upload.75179563.svg"
  },
  {
    "revision": "78c8cbe4613698f6ceba5dd618c41aad",
    "url": "./static/media/video.78c8cbe4.svg"
  }
]);