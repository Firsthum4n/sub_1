self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "0e37c3d95b0b1b6a3e44d383dafa4d7e",
    "url": "./index.html"
  },
  {
    "revision": "70ab64386eed4e1b45d7",
    "url": "./static/css/2.20245710.chunk.css"
  },
  {
    "revision": "f6d7695b86cb0d602563",
    "url": "./static/css/main.dce1ba4f.chunk.css"
  },
  {
    "revision": "70ab64386eed4e1b45d7",
    "url": "./static/js/2.f97c476c.chunk.js"
  },
  {
    "revision": "8067edf00042dc4464e4b3354e12578e",
    "url": "./static/js/2.f97c476c.chunk.js.LICENSE.txt"
  },
  {
    "revision": "f6d7695b86cb0d602563",
    "url": "./static/js/main.85e8bcf0.chunk.js"
  },
  {
    "revision": "350e0bde90825074ef5c",
    "url": "./static/js/runtime-main.4a004120.js"
  },
  {
    "revision": "1852db14267c8dfc239ecca729c9d413",
    "url": "./static/media/arrow.1852db14.svg"
  },
  {
    "revision": "ece0b3e5e6622929d4da119c501d9095",
    "url": "./static/media/audio.ece0b3e5.svg"
  },
  {
    "revision": "06df44b3685b4df167181532611ac3f1",
    "url": "./static/media/delete_icon.06df44b3.svg"
  },
  {
    "revision": "94328baa6fecef0ea11c2d280d9d5923",
    "url": "./static/media/download.94328baa.svg"
  },
  {
    "revision": "f19a11107da7f634d96467dfb4e86894",
    "url": "./static/media/mixedContent.f19a1110.svg"
  },
  {
    "revision": "65f6bff1e32c66bf47e4be6e3639d04e",
    "url": "./static/media/modal_close.65f6bff1.svg"
  },
  {
    "revision": "8432c07737add3f9c238e1a0a99c96a7",
    "url": "./static/media/plus.8432c077.svg"
  },
  {
    "revision": "93afa2cf58d3e2290d2255a51b162c77",
    "url": "./static/media/settings.93afa2cf.svg"
  },
  {
    "revision": "962cdd77a1ac1b27ea651f74153a0e5a",
    "url": "./static/media/upload.962cdd77.svg"
  },
  {
    "revision": "167f253547efa803ed4ab7cf95aa20f3",
    "url": "./static/media/video.167f2535.svg"
  }
]);